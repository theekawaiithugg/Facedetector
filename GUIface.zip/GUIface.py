import tkinter as tk
from tkinter import filedialog
from PIL import ImageTk, Image, ImageDraw
import face_recognition
import numpy as np
from deepface import DeepFace

def load_image():
    filename = filedialog.askopenfilename()
    if filename:
        image = Image.open(filename)  # Load the image using PIL
        
        # Resize the image to fit within a maximum size (e.g., 300x300 pixels)
        max_size = (300, 300)
        image.thumbnail(max_size, Image.LANCZOS)  # Use LANCZOS for high-quality downsampling

        # Optionally perform face detection and draw on the resized image
        face_locations = face_recognition.face_locations(np.array(image))  # Detect faces
        draw = ImageDraw.Draw(image)  # Create a drawing context

        face_count = len(face_locations)  # Count the detected faces
        print(f"Faces Detected: {face_count}")

        for i, face_location in enumerate(face_locations):
            top, left, bottom, right = face_location  # Unpack the face location tuple
            corrected_left, corrected_right = min(left, right), max(left, right)  # Ensure correct coordinates
            draw.rectangle(((corrected_left, top), (corrected_right, bottom)), outline="red", width=3)  # Draw rectangle around the face


        # Convert the image with rectangles to a PhotoImage and update the label
        image_tk = ImageTk.PhotoImage(image)
        label.config(image=image_tk)
        label.image = image_tk  # Keep a reference to avoid garbage collection

        # Analyze each detected face using DeepFace (Optional)
        for index, face_location in enumerate(face_locations):
            top, left, bottom, right = face_location
            corrected_left, corrected_right = min(left, right), max(left, right)  # Ensure correct coordinates for cropping
            # Crop the face to analyze
            face_image = image.crop((corrected_left, top, corrected_right, bottom))
            face_image.save("temp_face.jpg")
            
            try:
                analysis = DeepFace.analyze(img_path="temp_face.jpg", actions=['age', 'emotion', 'gender', 'race'], enforce_detection=False)
                print(f"Face {index + 1}: {analysis}")  # Print analysis result with face number

                age = analysis['age']
                dominant_emotion = analysis['dominant_emotion']
                dominant_gender = analysis['gender']
                dominant_race = analysis['race']
                print(f"Face {index + 1} - Estimated Age: {age}, Dominant Emotion: {dominant_emotion}, Dominant Gender: {dominant_gender}, Dominant Race: {dominant_race}")

            except Exception as e:
                print(f"Error in analyzing face {index + 1}:", e)

# Create the main window
root = tk.Tk()
root.title("Face Recognition")

# Create a label to display the image
label = tk.Label(root)
label.pack()

# Create a button to load an image
load_button = tk.Button(root, text="Load Image", command=load_image)
load_button.pack()

# Run the Tkinter event loop
root.mainloop()
